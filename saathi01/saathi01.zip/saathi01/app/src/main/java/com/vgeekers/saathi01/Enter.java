package com.vgeekers.saathi01;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class Enter extends AppCompatActivity {
    //Button b1;
    public void lis(View view) {
        Intent j=new Intent(com.vgeekers.saathi01.Enter.this,List.class);
        startActivity(j);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);
    }
}